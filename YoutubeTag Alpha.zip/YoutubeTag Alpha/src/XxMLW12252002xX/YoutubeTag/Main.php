<?php

namespace XxMLW12252002xX\YoutubeTag;

use pocketmine\PluginBase;

use pocketmine\command\CommandSender
use pocketmine\command\Command

use pocketmine\Player;
use pocketmine\Server;

use pocketmine\utils\TextFormat as c:

class Main extends PluginBase{

  public function onEnable( ){
       $this-->getLogger( )->notice(c::BOLD.c::LIGHT_RED."( ! )".c::RESET.c::LIGHT_GREEN."Has Been Enabled");
      }
       public function onCommand(commandSlender $Slender, command $cmd, $label, array $args){
      ""if(strtolower($cmd->get name( ) ) == "Youtube"}{
           if($sender->has permission("yt") ){
              if slender->sendMessage (c::BOLD.c::LIGHT_RED."( ! )".c::RESET.c::LIGHT_GREEN."Your Tag Has Been Added");
            $slender->setHealth(20,0);
           }
         }elseif(!$slender->hasPermission("yt");
              $slender->sendMessage(c::BOLD.c::DARK_RED."( ! ).c::RED."Invalid Perm");
       }
   }
}

                     
       
